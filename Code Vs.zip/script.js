document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('searchInput');
  const searchButton = document.getElementById('searchButton');
  const productList = document.getElementById('productList');
  const shopNameBox = document.getElementById('shopNameBox');
  const selectedShopName = document.getElementById('selectedShopName');
  const shopContact = document.getElementById('shopContact');
  const shopAddress = document.getElementById('shopAddress');
  const shopSuggestions = document.getElementById('shopSuggestions');

  // Sample shop names for demonstration
  const sampleShopNames = [
      'Kathmandu Steak House Restaurant',
      'Bisranti Restaurant And Bar',
      'Vishranti Sweets',
      'Dailo Daily See Us',
      'Raghav Food',
      'Manoj Food'
  ];

  // Sample shop data
  const shopData = [
      {
          name: 'X Food',
          contact: '777-888-9999',
          address: '321 Cedar St, City',
          categories: [
              {
                  name: 'Lunch',
                  products: [
                      { name: 'Rice', price: 50 }
                  ]
              }
          ]
      },
      {
          name: 'Raghav Food',
          contact: '111-222-3333',
          address: '789 Oak St, City',
          categories: [
              {
                  name: 'Breakfast',
                  products: [
                      { name: 'Roti', price: 30 }
                  ]
              }
          ]
      },
      {
          name: 'Kathmandu Steak House Restaurant',
          contact: '977-01-4264946',
          address: 'Chaksibari Marg, Thamel, Kathmandu (Nepal)',
          categories: [
            {
              name: 'Pasta',
              products: [
                { name: 'NEPOLITANA (VEGETABLE)', price: 470 },
                { name: 'AGLIO OLIO PEPERONCINO (VEGETABLE)', price: 370 },
                { name: 'ARRABIATA (VEGETABLE)', price: 480 },
                { name: 'CARBONARA', price: 570 },
                { name: 'BOLOGNESE', price: 570 },
              ]
            },
            {
              name: 'Soups',
              products: [
                { name: 'TOMATO AND BASIL SOUP (VEG)', price: 300 },
                { name: 'CREAM OF SPINACH (VEG)', price: 320 },
                { name: 'CREAM OF MUSHROOM (VEG)', price: 330 },
                { name: 'CREAM OF CHICKEN', price: 360 },
              ]
            },
            {
              name: 'Salads',
              products: [
                { name: 'ORGANIC GREEN SALAD (VEGETABLE)', price: 260 },
                { name: 'GRILLED CHICKEN SALAD', price: 350 },
                { name: 'MAXICANA SALAD', price: 415 },
                { name: 'CAESAR SALAD', price: 580 },
                { name: 'TREKKER\'S BEEF SALAD', price: 620 },
              ]
            },
            {
              name: 'Starters',
              products: [
                { name: 'HOUSE FRENCH FRIES (VEGETABLE)', price: 200 },
                { name: 'TEX MAX CHICKEN', price: 300 },
                { name: 'LA BRUSCHETTA (VEGETABLE)', price: 280 },
                { name: 'MUSHROOM CHILLI (VEGETABLE)', price: 370 },
                { name: 'CHEESE POPPERS (VEGETABLE)', price: 380 },
                { name: 'CHICKEN CHILLI', price: 390 },
                { name: 'ONION RINGS (VEGETABLE)', price: 250 },
                { name: 'CHIPS CHEESE FRIES (VEGETABLE)', price: 330 },
              ]
            },
            {
              name: 'Sandwiches - Burgers',
              products: [
                { name: 'Veg Burger', price: 375 },
                { name: 'Vegetable Sandwich', price: 375 },
                { name: 'Grilled Chicken Sandwich', price: 375 },
                { name: 'Chicken Burger', price: 410 },
                { name: 'California Beef Burger', price: 440 },
                { name: 'Ham Burger', price: 490 },
              ]
            },
            {
              name: 'MAIN COURSE',
              products: [
                { name: 'Veg. Parmigiana', price: 480 },
                { name: 'House Special Veg Steak', price: 450 },
                { name: 'Risotto Ai Funghi (Veg)', price: 625 },
                { name: 'Grilled Chicken Brest', price: 620 },
                { name: 'Salmon Steak', price: 1200 },
                { name: 'SPICE-RUBBED PORK', price: 675 },
                { name: 'Grilled Pork Chop', price: 860 },
                { name: 'Pork Spare Ribs', price: 880 },
              ]
            },
            {
              name: 'House Signature Ostrich Steak',
              products: [
                { name: 'FILET MIGNON', price: 1300 },
                { name: 'NEW YORK STRIP', price: 1295 },
                { name: 'FILLET DI MANZO', price: 1295 },
                { name: 'TREEKKERS\' SPECIAL STEAK', price: 1795 },
                { name: 'SIZZLING FLAME STEAK', price: 1700 },
                { name: 'KATHMANDU SIGNATURE STEAK', price: 2700 },
              ]
            },
            {
              name: 'Desserts',
              products: [
                { name: 'Fruit Salad', price: 370 },
                { name: 'Chocolate Brownie with ice cream', price: 360 },
                { name: 'Apple Crumble', price: 330 },
                { name: 'Blueberry Tart', price: 560 },
                { name: 'Banana Fritters', price: 250 },
                { name: 'Banana Split', price: 275 },
                { name: 'Two Scoop of Ice-Cream', price: 175 },
              ]
            },
            {
              name: 'NEPALI THALI',
              products: [
                { name: 'NEPALI VEG. THALI', price: 525 },
                { name: 'NEPALI NON-VEG. THALI', price: 625 },
              ]
            }
          ]            
      },
      {   
          name: 'Bisranti Restaurant And Bar',
          contact: '977-1-4483120',
          address: 'Bhimsengola Marg, Kathmandu (Nepal)',
          categories: [
              {
                  name: 'Momo',
                  products: [
                      { name: 'Chicken Momo', price: 130 },
                      { name: 'Buff Momo', price: 120 },
                      { name: 'Veg Momo', price: 100 },
                      { name: 'Chicken C Momo', price: 150 },
                      { name: 'Buff C Momo', price: 140 },
                      { name: 'Veg C Momo', price: 120 },
                      { name: 'Chicken Jhol Momo', price: 150 },
                      { name: 'Buff Jhol Momo', price: 140 },
                      { name: 'Veg Jhol Momo', price: 120 },
                      { name: 'Chicken Fried Momo', price: 140 },
                      { name: 'Buff Fried Momo', price: 130 },
                      { name: 'Veg Fried Momo', price: 120 },
                  ]
              },
              {
                  name: 'Chowmein',
                  products: [
                      { name: 'Chicken Chowmein', price: 120 },
                      { name: 'Buff Chowmein', price: 110 },
                      { name: 'Veg Chowmein', price: 90 },
                      { name: 'Egg Chowmein', price: 110 },
                  ]
              },
              {
                  name: 'Tea',
                  products: [
                      { name: 'Black Tea', price: 20 },
                      { name: 'Milk Tea', price: 30 },
                      { name: 'Hot Lemon', price: 30 },
                      { name: 'Lemon Tea', price: 25 },
                  ]
              },
              {
                  name: 'Coffee',
                  products: [
                      { name: 'Black Coffee', price: 40 },
                      { name: 'Milk Coffee', price: 60 },
                  ]
              },
              {
                  name: 'Chilly',
                  products: [
                      { name: 'Chicken Chilly Boneless', price: 250 },
                      { name: 'Buff Chilly', price: 200 },
                      { name: 'Buff Choila', price: 200 },
                      { name: 'Buff Sukuti', price: 200 },
                      { name: 'Chicken Sadeko', price: 250 },
                      { name: 'Chicken Lollipop 6 pcs', price: 200 },
                      { name: 'Barbeque Wings', price: 280 },
                  ]
              },
              {
                  name: 'Khana/Khaja Set',
                  products: [
                      { name: 'Veg Khana', price: 200 },
                      { name: 'Chicken Khana', price: 250 },
                      { name: 'Matton Khana', price: 300 },
                      { name: 'Buff Khaja Set', price: 180 },
                      { name: 'Chicken Khaja', price: 200 },
                  ]
              },
          ]
      },
      {
          name: 'Vishranti Sweets',
          contact: '977-01-5911000',
          address: 'Maitidevi, Kathmandu (Nepal)',
          categories: [
              {
                name: 'छिटो मिठो खाना',
                products: [
                  { name: 'Samosa', price: 30 },
                  { name: 'Samosa (2pc) + Chola', price: 120 },
                  { name: 'Dal Kachori', price: 35 },
                  { name: 'Onion Kachori', price: 45 },
                  { name: 'Puri Chola', price: 150 },
                  { name: 'Puri Chola + Jeri (2pc)', price: 200 },
                  { name: 'Choley Bhatura', price: 200 },
                  { name: 'Pav Bhaji', price: 250 },
                  { name: 'Chola', price: 60 },
                ]
              },
              {
                name: 'Chaat',
                products: [
                  { name: 'Mix Chaat', price: 180 },
                  { name: 'Kachori Chaat', price: 170 },
                  { name: 'Papadi Chaat', price: 170 },
                  { name: 'Samosa Chaat', price: 150 },
                  { name: 'Aloo Tikki Chaat', price: 170 },
                  { name: 'Raj Kachori Chaat', price: 200 },
                  { name: 'Dahi Bhalla', price: 180 },
                  { name: 'Dahi Puri Chaat', price: 180 },
                  { name: 'Pani puri', price: 100 },
                ]
              },
              {
                name: 'Snacks',
                products: [
                  { name: 'French Fries', price: 180 },
                  { name: 'Chips Chilly', price: 250 },
                  { name: 'Paneer Chilly', price: 300 },
                  { name: 'Mushroom Chilly', price: 300 },
                  { name: 'Veg Manchurian', price: 250 },
                  { name: 'Veg Pakoda', price: 120 },
                  { name: 'Paneer Pakoda', price: 250 },
                ]
              },
              {
                name: 'Beverage',
                products: [
                  { name: 'Fanta/ Sprite/ Coke', price: 60 },
                  { name: 'Sweet Lassi', price: 150 },
                  { name: 'Banana Lassi', price: 180 },
                  { name: 'Mineral Water', price: 30 },
                ]
              },
              {
                name: 'South Indian',
                products: [
                  { name: 'Vishranti Special Dosa', price: 450 },
                  { name: 'Paneer Dosa', price: 400 },
                  { name: 'Masala Dosa', price: 300 },
                  { name: 'Plain Dosa', price: 250 },
                  { name: 'Mysore Dosa', price: 300 },
                  { name: 'Hara Bhara Dosa', price: 300 },
                  { name: 'Cheese Masala Dosa', price: 400 },
                  { name: 'Idli Shambar', price: 200 },
                  { name: 'Shambar Vada', price: 200 },
                  { name: 'Mix Veg Uttapam', price: 300 },
                  { name: 'Plain Uttapam', price: 250 },
                  { name: 'Onion Tomato Uttapam', price: 300 },
                  { name: 'Paneer Utaapam', price: 350 },
                ]
              },
              {
                name: 'मः मः / चाउमिन',
                products: [
                  { name: 'Veg MO:MO', price: 150 },
                  { name: 'Veg Fry MO:MO', price: 180 },
                  { name: 'Veg C MO:MO', price: 200 },
                  { name: 'Veg Jhol MO:MO', price: 180 },
                  { name: 'Paneer MO:MO', price: 220 },
                  { name: 'Paneer Fry MO:MO', price: 250 },
                  { name: 'Paneer C MO:MO Paneer', price: 270 },
                  { name: 'Jhol MO:MO', price: 250 },
                  { name: 'Veg Chowmein', price: 150 },
                  { name: 'Vishranti Special Chowmein', price: 200 },
                ]
              },
              {
                name: 'Sweets',
                products: [
                  { name: 'Rasvari', price: 40 },
                  { name: 'Lalmohan', price: 40 },
                  { name: 'Rasmalai', price: 80 },
                  { name: 'Rasmadhuri', price: 100 },
                  { name: 'Malai Cham Cham', price: 150 },
                  { name: 'Rabdi 1', price: 120 },
                ]
              }
            ]              
      },
      {
          name: 'Dailo Daily See Us',
          contact: '977-9803074666',
          address: 'PC Complex, 1st Floor, New Baneshwor, Kathmandu (Nepal)',
          categories: [
              {
                name: 'JHOL JHAAL',
                products: [
                  { name: 'Creamy Mushroom Soup (V)', price: 260 },
                  { name: 'Mopka (VA)', price: 280 },
                ]
              },
              {
                name: 'SITANS SADHEKO (V)',
                products: [
                  { name: 'Bhatmaas', price: 200 },
                  { name: 'Peanuts', price: 225 },
                  { name: 'Sukuti', price: 360 },
                  { name: 'Bhutan', price: 390 },
                ]
              },
              {
                name: 'CHHOILAA (VA)',
                products: [
                  { name: 'Chicken', price: 380 },
                  { name: 'Mushroom', price: 400 },
                ]
              },
              {
                name: 'SEKUWA (VA)',
                products: [
                  { name: 'Chicken', price: 400 },
                  { name: 'Paneer', price: 450 },
                  { name: 'Pork', price: 500 },
                  { name: 'Mutton', price: 640 },
                ]
              },
              {
                name: 'TAAS',
                products: [
                  { name: 'Chicken', price: 400 },
                  { name: 'Mutton', price: 640 },
                  { name: 'Sikaari Plate', price: 1390 },
                ]
              },
              {
                name: 'CURRIES LEDO BEDO',
                products: [
                  { name: 'Chicken', price: 420 },
                  { name: 'Fish', price: 620 },
                  { name: 'Mutton', price: 630 },
                ]
              },
              {
                name: 'BUTTER MASALA (VA)',
                products: [
                  { name: 'Chicken', price: 430 },
                  { name: 'Paneer', price: 560 },
                  { name: 'Matar Paneer (V)', price: 480 },
                  { name: 'I am Curry', price: 1499 },
                ]
              },
              {
                name: 'TO TASTE',
                products: [
                  { name: 'Chicken Chilly', price: 350 },
                  { name: 'Pulled Chicken Loaded Fries', price: 360 },
                  { name: 'Mushroom Chilly (V)', price: 390 },
                  { name: 'Buffalo Wings', price: 390 },
                  { name: 'Crumbed Fried Chicken', price: 390 },
                  { name: 'Paneer chilly (V)', price: 480 },
                ]
              },
              {
                name: 'SIZZLER (VA)',
                products: [
                  { name: 'Veg', price: 350 },
                  { name: 'Chicken', price: 490 },
                ]
              },
              {
                name: 'CHEF\'S SPECIAL HOTPAN (VA)',
                products: [
                  { name: 'Chicken', price: 490 },
                  { name: 'Paneer', price: 520 },
                ]
              },
              {
                name: 'RICE & ROTIS',
                products: [
                  { name: 'Taawa Roti', price: 50 },
                  { name: 'Paratha (V)', price: 70 },
                  { name: 'Ghiu Bhaat', price: 150 },
                  { name: 'Jeera Rice (V)', price: 150 },
                  { name: 'Aalo Paratha (V)', price: 130 },
                  { name: 'Bihe ko Pulao (V)', price: 250 },
                ]
              },
              {
                name: 'BIRYANI',
                products: [
                  { name: 'Hydrabaadi Dum Biryani (VA) Veg', price: 400 },
                  { name: 'Hydrabaadi Dum Biryani (VA) Chicken', price: 550 },
                  { name: 'Hydrabaadi Dum Biryani (VA) Mutton', price: 650 },
                ]
              },
              {
                name: 'SALADS',
                products: [
                  { name: 'Nepalese Royal Salad (V)', price: 250 },
                  { name: 'Teaser Salad', price: 350 },
                  { name: 'Mixed Fruit Salad (V)', price: 450 },
                ]
              },
              {
                name: 'PIZZA',
                products: [
                  { name: 'Dailo Ko Pizza (VA) Chicken', price: 520 },
                  { name: 'Dailo Ko Pizza (VA) Mushroom', price: 550 },
                ]
              },
              {
                name: 'PASTA',
                products: [
                  { name: 'Carbonara', price: 400 },
                  { name: 'Bolognese', price: 420 },
                ]
              },
              {
                name: 'FIRST LOVE',
                products: [
                  { name: 'Bruschetta Chat (v)', price: 200 },
                  { name: 'Aalotini - Mustaangi (V)', price: 260 },
                  { name: 'Naanja (V)', price: 300 },
                ]
              },
              {
                name: 'DAILO\'S SPECIAL',
                products: [
                  { name: 'Original Chhoila Burger (VA) Chicken / Mushroom', price: 295 },
                  { name: 'Burgers Loaded chicken burger', price: 350 },
                ]
              },
              {
                name: 'DAILO PLATTERS',
                products: [
                  { name: 'Mo:Mo (veg)', price: 350 },
                  { name: 'Mo:Mo (Buff)', price: 400 },
                  { name: 'Mo:Mo (Chicken)', price: 450 },
                ]
              },
              {
                name: 'ANEKTHARI',
                products: [
                  { name: 'Anekthari', price: 799 },
                ]
              },
              {
                name: 'VEG PLATTER',
                products: [
                  { name: 'Veg Platter', price: 899 },
                ]
              },
              {
                name: 'NON-VEG PLATTER',
                products: [
                  { name: 'Non-Veg Platter', price: 999 },
                ]
              },
              {
                name: 'NAI NABHANNU LA (MOMO:)',
                products: [
                  { name: 'Paneer veg Mo:Mo (STEAMED)', price: 180 },
                  { name: 'Paneer veg Mo:Mo (SAADHEKO)', price: 220 },
                  { name: 'Paneer veg Mo:Mo (KURKURE)', price: 240 },
                  { name: 'Paneer veg Mo:Mo (JHOL)', price: 250 },
                  { name: 'Paneer veg Mo:Mo (C MO:MO)', price: 280 },
                  { name: 'Chicken Mo:Mo (STEAMED)', price: 190 },
                  { name: 'Chicken Mo:Mo (SAADHEKO)', price: 220 },
                  { name: 'Chicken Mo:Mo (KURKURE)', price: 250 },
                  { name: 'Chicken Mo:Mo (JHOL)', price: 260 },
                  { name: 'Chicken Mo:Mo (C MO:MO)', price: 280 },
                  { name: 'Buff Mo:Mo (STEAMED)', price: 180 },
                  { name: 'Buff Mo:Mo (SAADHEKO)', price: 220 },
                  { name: 'Buff Mo:Mo (KURKURE)', price: 260 },
                  { name: 'Buff Mo:Mo (JHOL)', price: 250 },
                  { name: 'Buff Mo:Mo (C MO:MO)', price: 280 },
                ]
              },
              {
                name: '... AND THE REST',
                products: [
                  { name: 'Chownmein (VA) Veg', price: 170 },
                  { name: 'Chownmein (VA) Buff', price: 190 },
                  { name: 'Chownmein (VA) Chicken', price: 200 },
                ]
              },
              {
                name: 'FRIED RICE (VA)',
                products: [
                  { name: 'Fried Rice (VA) Veg', price: 200 },
                  { name: 'Fried Rice (VA) Egg', price: 240 },
                  { name: 'Fried Rice (VA) Buff', price: 270 },
                  { name: 'Fried Rice (VA) Chicken', price: 280 },
                ]
              },
              {
                name: 'KATHI ROLL (VA)',
                products: [
                  { name: 'Kathi Roll (VA) Chicken', price: 350 },
                  { name: 'Kathi Roll (VA) Paneer', price: 400 },
                  { name: 'Kathi Roll (VA) Maya Dharane', price: 540 },
                  { name: 'Kathi Roll (VA) Desi Parmigiana', price: 580 },
                ]
              },
              {
                name: 'CHHUTLANI',
                products: [
                  { name: 'Rolled Mince', price: 180 },
                  { name: 'Chicken Meatballs', price: 220 },
                  { name: 'Twakka Makai (V)', price: 320 },
                  { name: 'French Fries (V)', price: 190 },
                  { name: 'Chips Chilly (V)', price: 250 },
                ]
              }
            ]   
      },
      {
          name: 'Manoj Food',
          contact: '777-888-9999',
          address: '321 Cedar St, City',
          categories: [
              {
                  name: 'Lunch',
                  products: [
                      { name: 'Rice', price: 50 }
                  ]
              }
          ]
      }, 
      // Add more shops and products here
  ];

  // Function to display products for a given shop name
  const displayProductsByShop = (shopName) => {
      productList.innerHTML = ''; // Clear previous results

      const selectedShop = shopData.find(shop => shop.name === shopName);

      if (selectedShop) {
          selectedShopName.textContent = selectedShop.name;
          shopContact.innerHTML = `<strong>Contact:</strong> <a href="tel:${selectedShop.contact}">${selectedShop.contact}</a>`;
          shopAddress.textContent = 'Address: ' + selectedShop.address;

          // Loop through categories and products, preserving the order
          selectedShop.categories.forEach(category => {
              const categoryTitle = document.createElement('div');
              categoryTitle.textContent = category.name;
              categoryTitle.classList.add('category-title');
              productList.appendChild(categoryTitle);

              category.products.forEach(product => {
                  const listItem = document.createElement('li');
                  listItem.innerHTML = `<div><strong>Name:</strong> ${product.name}</div>
                                        <div><strong>Price:</strong> Rs ${product.price}</div>`;
                  productList.appendChild(listItem);
              });
          });

          shopNameBox.style.display = 'block';
      } else {
          productList.innerHTML = '<li>No products found for this shop.</li>';
          shopNameBox.style.display = 'none';
      }
  };

  // Event listener for the search button
  searchButton.addEventListener('click', () => {
      const query = searchInput.value.trim();

      if (query) {
          displayProductsByShop(query);
          shopSuggestions.style.display = 'none'; // Hide suggestions
      }
  });

  // Event listener for input changes to show shop name suggestions
  searchInput.addEventListener('input', () => {
      const inputValue = searchInput.value.trim().toLowerCase().replace(/\s+/g, '');
      let matchedSuggestions = sampleShopNames.filter(shop => {
          const sanitizedShopName = shop.toLowerCase().replace(/\s+/g, '');
          return sanitizedShopName.includes(inputValue);
      });

      // Sort suggestions in ascending order
      matchedSuggestions = matchedSuggestions.sort();

      if (matchedSuggestions.length > 0) {
          shopSuggestions.style.display = 'block';
          shopSuggestions.innerHTML = ''; // Clear previous suggestions

          matchedSuggestions.forEach(suggestion => {
              const suggestionItem = document.createElement('div');
              suggestionItem.textContent = suggestion;
              suggestionItem.classList.add('suggestion-item');
              suggestionItem.addEventListener('click', () => {
                  searchInput.value = suggestion;
                  displayProductsByShop(suggestion);
                  shopSuggestions.style.display = 'none'; // Hide suggestions on selection
              });
              shopSuggestions.appendChild(suggestionItem);
          });
      } else {
          shopSuggestions.style.display = 'none'; // Hide suggestions if no matches
      }
  });
});
