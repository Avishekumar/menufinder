document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const productList = document.getElementById('productList');
    const shopNameBox = document.getElementById('shopNameBox');
    const selectedShopName = document.getElementById('selectedShopName');
    const shopContact = document.getElementById('shopContact');
    const shopAddress = document.getElementById('shopAddress');
    const shopSuggestions = document.getElementById('shopSuggestions');

    // Sample shop names for demonstration
    const sampleShopNames = [
        'Bisranti Restaurant And Bar',
        'Vishranti Sweets',
        'Mohan Food',
        'Suraj Hotels',
        'Manoj Food'
    ];

    // Sample shop data
    const shopData = [
        {
            name: 'Bisranti Restaurant And Bar',
            contact: '977-1-4483120',
            address: 'Bhimsengola Marg, Kathmandu (Nepal)',
            categories: [
                {
                    name: 'Momo',
                    products: [
                        { name: 'Chicken Momo', price: 130 },
                        { name: 'Buff Momo', price: 120 },
                        { name: 'Veg Momo', price: 100 },
                        { name: 'Chicken C Momo', price: 150 },
                        { name: 'Buff C Momo', price: 140 },
                        { name: 'Veg C Momo', price: 120 },
                        { name: 'Chicken Jhol Momo', price: 150 },
                        { name: 'Buff Jhol Momo', price: 140 },
                        { name: 'Veg Jhol Momo', price: 120 },
                        { name: 'Chicken Fried Momo', price: 140 },
                        { name: 'Buff Fried Momo', price: 130 },
                        { name: 'Veg Fried Momo', price: 120 },
                    ]
                },
                {
                    name: 'Chowmein',
                    products: [
                        { name: 'Chicken Chowmein', price: 120 },
                        { name: 'Buff Chowmein', price: 110 },
                        { name: 'Veg Chowmein', price: 90 },
                        { name: 'Egg Chowmein', price: 110 },
                    ]
                },
                {
                    name: 'Tea',
                    products: [
                        { name: 'Black Tea', price: 20 },
                        { name: 'Milk Tea', price: 30 },
                        { name: 'Hot Lemon', price: 30 },
                        { name: 'Lemon Tea', price: 25 },
                    ]
                },
                {
                    name: 'Coffee',
                    products: [
                        { name: 'Black Coffee', price: 40 },
                        { name: 'Milk Coffee', price: 60 },
                    ]
                },
                {
                    name: 'Chilly',
                    products: [
                        { name: 'Chicken Chilly Boneless', price: 250 },
                        { name: 'Buff Chilly', price: 200 },
                        { name: 'Buff Choila', price: 200 },
                        { name: 'Buff Sukuti', price: 200 },
                        { name: 'Chicken Sadeko', price: 250 },
                        { name: 'Chicken Lollipop 6 pcs', price: 200 },
                        { name: 'Barbeque Wings', price: 280 },
                    ]
                },
                {
                    name: 'Khana/Khaja Set',
                    products: [
                        { name: 'Veg Khana', price: 200 },
                        { name: 'Chicken Khana', price: 250 },
                        { name: 'Matton Khana', price: 300 },
                        { name: 'Buff Khaja Set', price: 180 },
                        { name: 'Chicken Khaja', price: 200 },
                    ]
                },
            ]
        },
        {
            name: 'Vishranti Sweets',
            contact: '977-01-5911000',
            address: 'Maitidevi, Kathmandu (Nepal)',
            categories: [
                {
                  name: 'छिटो मिठो खाना',
                  products: [
                    { name: 'Samosa', price: 30 },
                    { name: 'Samosa (2pc) + Chola', price: 120 },
                    { name: 'Dal Kachori', price: 35 },
                    { name: 'Onion Kachori', price: 45 },
                    { name: 'Puri Chola', price: 150 },
                    { name: 'Puri Chola + Jeri (2pc)', price: 200 },
                    { name: 'Choley Bhatura', price: 200 },
                    { name: 'Pav Bhaji', price: 250 },
                    { name: 'Chola', price: 60 },
                  ]
                },
                {
                  name: 'Chaat',
                  products: [
                    { name: 'Mix Chaat', price: 180 },
                    { name: 'Kachori Chaat', price: 170 },
                    { name: 'Papadi Chaat', price: 170 },
                    { name: 'Samosa Chaat', price: 150 },
                    { name: 'Aloo Tikki Chaat', price: 170 },
                    { name: 'Raj Kachori Chaat', price: 200 },
                    { name: 'Dahi Bhalla', price: 180 },
                    { name: 'Dahi Puri Chaat', price: 180 },
                    { name: 'Pani puri', price: 100 },
                  ]
                },
                {
                  name: 'Snacks',
                  products: [
                    { name: 'French Fries', price: 180 },
                    { name: 'Chips Chilly', price: 250 },
                    { name: 'Paneer Chilly', price: 300 },
                    { name: 'Mushroom Chilly', price: 300 },
                    { name: 'Veg Manchurian', price: 250 },
                    { name: 'Veg Pakoda', price: 120 },
                    { name: 'Paneer Pakoda', price: 250 },
                  ]
                },
                {
                  name: 'Beverage',
                  products: [
                    { name: 'Fanta/ Sprite/ Coke', price: 60 },
                    { name: 'Sweet Lassi', price: 150 },
                    { name: 'Banana Lassi', price: 180 },
                    { name: 'Mineral Water', price: 30 },
                  ]
                },
                {
                  name: 'South Indian',
                  products: [
                    { name: 'Vishranti Special Dosa', price: 450 },
                    { name: 'Paneer Dosa', price: 400 },
                    { name: 'Masala Dosa', price: 300 },
                    { name: 'Plain Dosa', price: 250 },
                    { name: 'Mysore Dosa', price: 300 },
                    { name: 'Hara Bhara Dosa', price: 300 },
                    { name: 'Cheese Masala Dosa', price: 400 },
                    { name: 'Idli Shambar', price: 200 },
                    { name: 'Shambar Vada', price: 200 },
                    { name: 'Mix Veg Uttapam', price: 300 },
                    { name: 'Plain Uttapam', price: 250 },
                    { name: 'Onion Tomato Uttapam', price: 300 },
                    { name: 'Paneer Utaapam', price: 350 },
                  ]
                },
                {
                  name: 'मः मः / चाउमिन',
                  products: [
                    { name: 'Veg MO:MO', price: 150 },
                    { name: 'Veg Fry MO:MO', price: 180 },
                    { name: 'Veg C MO:MO', price: 200 },
                    { name: 'Veg Jhol MO:MO', price: 180 },
                    { name: 'Paneer MO:MO', price: 220 },
                    { name: 'Paneer Fry MO:MO', price: 250 },
                    { name: 'Paneer C MO:MO Paneer', price: 270 },
                    { name: 'Jhol MO:MO', price: 250 },
                    { name: 'Veg Chowmein', price: 150 },
                    { name: 'Vishranti Special Chowmein', price: 200 },
                  ]
                },
                {
                  name: 'Sweets',
                  products: [
                    { name: 'Rasvari', price: 40 },
                    { name: 'Lalmohan', price: 40 },
                    { name: 'Rasmalai', price: 80 },
                    { name: 'Rasmadhuri', price: 100 },
                    { name: 'Malai Cham Cham', price: 150 },
                    { name: 'Rabdi 1', price: 120 },
                  ]
                }
              ]              
        },
        {
            name: 'Mohan Food',
            contact: '111-222-3333',
            address: '789 Oak St, City',
            categories: [
                {
                    name: 'Breakfast',
                    products: [
                        { name: 'Roti', price: 30 }
                    ]
                }
            ]
        },
        {
            name: 'Suraj Hotels',
            contact: '444-555-6666',
            address: '567 Pine St, City',
            categories: [
                {
                    name: 'Snacks',
                    products: [
                        { name: 'Veg Mo:Mo', price: 60 },
                        { name: 'Chicken Mo:Mo', price: 160 },
                    ]
                },
                {
                    name: 'Dinner',
                    products: [
                        { name: 'Non-Veg Khana', price: 170 }
                    ]
                }
            ]
        },
        {
            name: 'Manoj Food',
            contact: '777-888-9999',
            address: '321 Cedar St, City',
            categories: [
                {
                    name: 'Lunch',
                    products: [
                        { name: 'Rice', price: 50 }
                    ]
                }
            ]
        }
        // Add more shops and products here
    ];

    // Function to display products for a given shop name
    const displayProductsByShop = (shopName) => {
        productList.innerHTML = ''; // Clear previous results

        const selectedShop = shopData.find(shop => shop.name === shopName);

        if (selectedShop) {
            selectedShopName.textContent = selectedShop.name;
            shopContact.innerHTML = `<strong>Contact:</strong> <a href="tel:${selectedShop.contact}">${selectedShop.contact}</a>`;
            shopAddress.textContent = 'Address: ' + selectedShop.address;

            // Loop through categories and products, preserving the order
            selectedShop.categories.forEach(category => {
                const categoryTitle = document.createElement('div');
                categoryTitle.textContent = category.name;
                categoryTitle.classList.add('category-title');
                productList.appendChild(categoryTitle);

                category.products.forEach(product => {
                    const listItem = document.createElement('li');
                    listItem.innerHTML = `<div><strong>Name:</strong> ${product.name}</div>
                                          <div><strong>Price:</strong> Rs ${product.price}</div>`;
                    productList.appendChild(listItem);
                });
            });

            shopNameBox.style.display = 'block';
        } else {
            productList.innerHTML = '<li>No products found for this shop.</li>';
            shopNameBox.style.display = 'none';
        }
    };

    // Event listener for the search button
    searchButton.addEventListener('click', () => {
        const query = searchInput.value.trim();

        if (query) {
            displayProductsByShop(query);
            shopSuggestions.style.display = 'none'; // Hide suggestions
        }
    });

    // Event listener for input changes to show shop name suggestions
    searchInput.addEventListener('input', () => {
        const inputValue = searchInput.value.trim().toLowerCase().replace(/\s+/g, '');
        let matchedSuggestions = sampleShopNames.filter(shop => {
            const sanitizedShopName = shop.toLowerCase().replace(/\s+/g, '');
            return sanitizedShopName.includes(inputValue);
        });

        // Sort suggestions in ascending order
        matchedSuggestions = matchedSuggestions.sort();

        if (matchedSuggestions.length > 0) {
            shopSuggestions.style.display = 'block';
            shopSuggestions.innerHTML = ''; // Clear previous suggestions

            matchedSuggestions.forEach(suggestion => {
                const suggestionItem = document.createElement('div');
                suggestionItem.textContent = suggestion;
                suggestionItem.classList.add('suggestion-item');
                suggestionItem.addEventListener('click', () => {
                    searchInput.value = suggestion;
                    displayProductsByShop(suggestion);
                    shopSuggestions.style.display = 'none'; // Hide suggestions on selection
                });
                shopSuggestions.appendChild(suggestionItem);
            });
        } else {
            shopSuggestions.style.display = 'none'; // Hide suggestions if no matches
        }
    });
});
